# USADI (Starter Bundle)

This bundle lets you run the **USADI** backend locally and test the mobile app.

## Quick Start (Windows, no Docker)

1) Install Python 3.11 and Node.js (optional, for the mobile app).
2) Open **PowerShell** in this folder and run:
```powershell
scripts\windows\setup_and_run.ps1
```
3) Open http://localhost:8000/health to verify the API.
4) (Optional) Mobile app: `cd mobile && npm install && npx expo start`

## Quick Start (Docker Desktop)

1) Install Docker Desktop for Windows.
2) Open PowerShell in this folder and run:
```powershell
scripts\windows\run_docker_compose.ps1
```
3) Open http://localhost:8000/health

## Endpoints
- `POST /daily_playbook` — returns a projection + narrative (demo values).
- `POST /projection` — returns basic projection stats for a given payload.
- `GET /metrics` — Prometheus metrics.

> This starter is minimal and safe for local testing. The full production spec (brokers, risk engine, TD adapter, orchestrator, CI/CD, etc.) can be layered on top.
