# Runs the backend using Docker Desktop on Windows
docker compose up --build
