# Creates a Python venv, installs backend deps, and runs the API on Windows
param(
  [string]$Python = "python"
)

Write-Host "Creating virtual environment..." -ForegroundColor Cyan
$venvPath = ".\.venv"
& $Python -m venv $venvPath

Write-Host "Activating venv and installing requirements..." -ForegroundColor Cyan
& .\.venv\Scripts\pip.exe install --upgrade pip
& .\.venv\Scripts\pip.exe install -r backend\app\requirements.txt

Write-Host "Starting FastAPI backend on http://localhost:8000 ..." -ForegroundColor Green
& .\.venv\Scripts\uvicorn.exe app.main:app --host 0.0.0.0 --port 8000 --reload --app-dir backend
