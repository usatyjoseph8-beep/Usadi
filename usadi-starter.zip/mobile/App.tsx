import React, { useEffect, useState } from 'react';
import { SafeAreaView, View, Text, TextInput, Button } from 'react-native';

const DEFAULT_API = 'http://localhost:8000';

export default function App(){
  const [api, setApi] = useState(DEFAULT_API);
  const [data, setData] = useState<any>(null);

  async function fetchPlaybook(){
    try{
      const res = await fetch(`${api}/daily_playbook`, {
        method:'POST', headers:{'Content-Type':'application/json'},
        body: JSON.stringify({ portfolio:[{type:'EQUITY', symbol:'AAPL', price:180, position:10}], prices:{} })
      });
      const json = await res.json();
      setData(json);
    } catch(e){
      setData({ error: String(e) });
    }
  }

  useEffect(()=>{ fetchPlaybook(); }, []);

  return (
    <SafeAreaView style={{padding:16}}>
      <Text style={{fontSize:22, fontWeight:'600'}}>USADI</Text>
      <Text>Backend API URL:</Text>
      <View style={{flexDirection:'row', alignItems:'center'}}>
        <TextInput value={api} onChangeText={setApi} style={{borderWidth:1, padding:8, flex:1}} />
        <View style={{width:8}}/>
        <Button title="Refresh" onPress={fetchPlaybook} />
      </View>
      <View style={{marginTop:16}}>
        <Text style={{fontWeight:'600'}}>Daily Playbook:</Text>
        <Text selectable>{JSON.stringify(data, null, 2)}</Text>
      </View>
    </SafeAreaView>
  );
}
