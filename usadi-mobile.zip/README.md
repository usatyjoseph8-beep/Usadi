# USADI Mobile (Expo)

## Install
```bash
npm install
```

## Run
```bash
npm start
```
Use Expo Go to scan the QR and open the app. Ensure your backend is running at the `apiBase` configured in app.json (defaults to http://localhost:8000).

## Screens
- Login (TD OAuth via backend)
- Dashboard (Daily Playbook)
- History (48h Canary Report)
- Strategies (Enable/disable strategies)
- Settings (view/change API base in config)
