import Constants from 'expo-constants';
export const API_BASE = (Constants.expoConfig?.extra as any)?.apiBase || 'http://localhost:8000';
export const OAUTH_REDIRECT = 'usadi://oauth-callback';
